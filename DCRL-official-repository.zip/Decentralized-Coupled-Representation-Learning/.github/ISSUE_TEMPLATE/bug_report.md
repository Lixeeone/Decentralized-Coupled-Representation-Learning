---
name: Numerical or implementation issue
about: Report a reproducible failure
title: ""
labels: bug
assignees: ""
---

**Command and configuration**

Include the command, configuration, seed, and expected behavior.

**Observed behavior**

Include the error and relevant diagnostic fields.

**Environment**

Attach the run's `metadata.json` after checking input filenames for personal information.

**Minimal input**

Prefer a small synthetic example or an input checksum. Do not upload private datasets or credentials.
