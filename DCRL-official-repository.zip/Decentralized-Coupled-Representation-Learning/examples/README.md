# Measured release examples

The `validation/` directory contains numerical outputs from the validation commands in [VALIDATION.md](../docs/VALIDATION.md). These are release-configuration results, not manuscript table values.

Only `validation/quickstart/` includes full state arrays/checkpoints. Other suites keep compact measured records. Raw diverged runs remain visible and their summaries label the last finite state. Complete-grid graph errors are missing where an evaluation query has no neighbors.

Generate new outputs in `results/`; do not overwrite these records when running another protocol. The config, input and source fingerprints document the provenance of each measured result.
